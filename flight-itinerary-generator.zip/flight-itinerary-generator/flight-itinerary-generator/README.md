# Flight Itinerary Generator

The browser interface, page views, styles, scripts and airport/airline reference data are bundled into `index.html`.

## Run

On Windows, double-click `start.bat`. It starts the small Node.js server and opens `http://127.0.0.1:8080` in your browser. The server is required for reviews to be shared between visitors; reviews are stored in `database/reviews.json`.

For other computers on the same Wi-Fi, open `http://COMPUTER-IP:8080`, replacing `COMPUTER-IP` with the server computer's local address.

Itinerary drafts and settings stay in the browser's local storage. Printing and Save as PDF use the browser's print dialog. Live flight schedules require an Aviationstack key and internet access.

Generated itineraries are samples, not confirmed reservations, tickets, boarding passes, or proof of travel.
