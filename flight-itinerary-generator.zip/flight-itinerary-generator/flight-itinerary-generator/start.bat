@echo off
title Flight Itinerary Generator
cd /d "%~dp0"
echo Starting Flight Itinerary Generator...
powershell -NoProfile -Command "try { $null = Invoke-RestMethod -Uri 'http://127.0.0.1:8080/api/health' -TimeoutSec 1; exit 0 } catch { exit 1 }"
if not errorlevel 1 (
    echo Review server is already running.
    start "" http://127.0.0.1:8080
    exit /b 0
)
set "NODE_EXE="
where node >nul 2>nul
if not errorlevel 1 set "NODE_EXE=node"
if not defined NODE_EXE for /d %%P in ("%LOCALAPPDATA%\Microsoft\WinGet\Packages\OpenJS.NodeJS.LTS_*") do for /d %%D in ("%%~fP\node-v*-win-x64") do if exist "%%~fD\node.exe" set "NODE_EXE=%%~fD\node.exe"
if not defined NODE_EXE (
    echo Node.js is required. Install Node.js LTS, then run this file again.
    pause
    exit /b 1
)
start "Flight Itinerary Server" /min "%NODE_EXE%" server.js
for /L %%I in (1,1,15) do (
    powershell -NoProfile -Command "try { $null = Invoke-RestMethod -Uri 'http://127.0.0.1:8080/api/health' -TimeoutSec 1; exit 0 } catch { exit 1 }"
    if not errorlevel 1 goto open_browser
    timeout /t 1 /nobreak >nul
)
echo The review server did not start. Check the minimized server window for an error.
pause
exit /b 1

:open_browser
start "" http://127.0.0.1:8080
exit /b 0
