"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");

const root = __dirname;
const port = Number(process.env.PORT) || 8080;
const database = path.join(root, "database");
const reviewsFile = path.join(database, "reviews.json");
const mime = { ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8", ".js":"application/javascript; charset=utf-8", ".json":"application/json; charset=utf-8", ".webmanifest":"application/manifest+json; charset=utf-8", ".jpg":"image/jpeg", ".jpeg":"image/jpeg", ".png":"image/png", ".svg":"image/svg+xml", ".ico":"image/x-icon", ".pdf":"application/pdf" };
const reviewAttempts = new Map();

function readReviews() { try { const data = JSON.parse(fs.readFileSync(reviewsFile, "utf8")); return Array.isArray(data) ? data : []; } catch (error) { return []; } }
function writeReviews(reviews) { fs.mkdirSync(database, { recursive: true }); const temp = reviewsFile + ".tmp"; fs.writeFileSync(temp, JSON.stringify(reviews, null, 2), { mode: 0o600 }); fs.renameSync(temp, reviewsFile); }
function send(res, status, data) { res.writeHead(status, { "Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store", "Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"Content-Type, Authorization", "Access-Control-Allow-Methods":"GET, POST, OPTIONS", "X-Content-Type-Options":"nosniff" }); res.end(JSON.stringify(data)); }
function readBody(req) { return new Promise((resolve, reject) => { let body = ""; req.on("data", chunk => { body += chunk; if (body.length > 8192) { reject(new Error("Request is too large")); req.destroy(); } }); req.on("end", () => { try { resolve(JSON.parse(body || "{}")); } catch (error) { reject(new Error("Invalid request")); } }); req.on("error", reject); }); }
function allowedReview(req) {
    const ip = req.socket.remoteAddress || "unknown", now = Date.now(), recent = (reviewAttempts.get(ip) || []).filter(time => now - time < 10 * 60 * 1000);
    if (recent.length >= 5) return false;
    recent.push(now); reviewAttempts.set(ip, recent); return true;
}
function reviewRoute(req, res) {
    if (req.method === "OPTIONS") return send(res, 204, {});
    if (req.method === "GET") return send(res, 200, { reviews:readReviews().slice().reverse() });
    if (req.method !== "POST") return send(res, 405, { error:"Method not allowed." });
    if (!allowedReview(req)) return send(res, 429, { error:"Please wait a few minutes before sending another review." });
    return readBody(req).then(body => {
        const review = String(body.review || "").trim();
        const rating = Number(body.rating);
        if (review.length < 3 || review.length > 1200) return send(res, 400, { error:"Review must be between 3 and 1,200 characters." });
        if (!Number.isInteger(rating) || rating < 1 || rating > 5) return send(res, 400, { error:"Choose a rating from 1 to 5." });
        const entry = { id:Date.now().toString(36) + Math.random().toString(36).slice(2, 8), name:String(body.name || "").trim().slice(0, 60) || "Anonymous", rating, review, createdAt:new Date().toISOString() };
        const reviews = readReviews(); reviews.push(entry); writeReviews(reviews);
        return send(res, 201, { review:entry });
    }).catch(error => { if (!res.headersSent) send(res, 400, { error:error.message || "Review could not be saved." }); });
}

http.createServer((req, res) => {
    try {
        const url = new URL(req.url, "http://localhost");
        if (url.pathname === "/api/reviews") return reviewRoute(req, res);
        if (url.pathname === "/api/health") return send(res, 200, { ok:true, app:"flight-itinerary-generator", time:new Date().toISOString() });
        let pathname = decodeURIComponent(url.pathname); if (pathname === "/") pathname = "/index.html";
        const target = path.resolve(root, "." + pathname);
        if (target !== root && !target.startsWith(root + path.sep)) { res.writeHead(403); return res.end("Forbidden"); }
        if (target === database || target.startsWith(database + path.sep)) { res.writeHead(404); return res.end("Not found"); }
        fs.stat(target, (error, stat) => { if (error || !stat.isFile()) { res.writeHead(404, { "Content-Type":"text/plain; charset=utf-8" }); return res.end("Not found"); } res.writeHead(200, { "Content-Type":mime[path.extname(target).toLowerCase()] || "application/octet-stream", "Cache-Control":/\.(json|html|js|css|webmanifest)$/.test(target) ? "no-cache" : "public, max-age=3600", "X-Content-Type-Options":"nosniff" }); fs.createReadStream(target).pipe(res); });
    } catch (error) { res.writeHead(500); res.end("Server error"); }
}).listen(port, "0.0.0.0", () => console.log(`Flight Itinerary Generator: http://127.0.0.1:${port}\nOther devices: use this computer's Wi-Fi IPv4 address on port ${port}.`));
